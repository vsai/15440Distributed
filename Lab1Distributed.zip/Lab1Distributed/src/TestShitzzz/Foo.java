package TestShitzzz;

 class Foo {

	public void run()
	{
		System.out.println("Im running");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
